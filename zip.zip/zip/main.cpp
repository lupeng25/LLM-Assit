#include <QApplication>
#include "Frm_AIAssit.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    Frm_AIAssit w;
    w.show();
    return app.exec();
}
