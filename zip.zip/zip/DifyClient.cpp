#include "DifyClient.h"

DifyClient::DifyClient(QObject *parent)
	: MessageManager(parent)
{
	m_LLMParams = new LLMParams();
	m_NetWorkParams = new ClientNetWork();

	// ��ʼ�����Ӳ��Զ�ʱ��
	m_connectionCheckTimer = new QTimer(this);
	m_connectionCheckTimer->setSingleShot(true);
	connect(m_connectionCheckTimer, &QTimer::timeout, this, &DifyClient::onCheckConnectionTimeout);

	// ��ʼ����ȡģ���б���ʱ��
	m_fetchModelsTimer = new QTimer(this);
	m_fetchModelsTimer->setSingleShot(true);
	connect(m_fetchModelsTimer, &QTimer::timeout, this, &DifyClient::onFetchModelsTimeout);

	m_currentRequestType = RequestType::ConnectionCheck;
}

DifyClient::~DifyClient()
{
}

AIProvider DifyClient::getProvider() const
{
	return AIProvider::Dify;
}

QString DifyClient::getProviderName() const
{
	return "Dify";
}

QString DifyClient::getVersion() const
{
	return "1.0";
}

void DifyClient::setConversationId(const QString& conversationId)
{
	m_conversationId = conversationId;
}

void DifyClient::setMessageId(const QString& messageId)
{
	m_messageId = messageId;
}

void DifyClient::setTaskId(const QString& taskId)
{
	m_taskId = taskId;
}

void DifyClient::setUserId(const QString& userId)
{
	m_userId = userId;
}

QString DifyClient::getConversationId() const
{
	return m_conversationId;
}

QString DifyClient::getUserId() const
{
	return m_userId;
}

QString DifyClient::getTaskId() const
{
	return m_taskId;
}

QString DifyClient::getMessageId() const
{
	return m_messageId;
}

void DifyClient::resetConversationId()
{
	m_conversationId.clear();
}

void DifyClient::resetUserId()
{
	m_userId.clear();
}

void DifyClient::resetTaskId()
{
	m_taskId.clear();
}

void DifyClient::resetMessageId()
{
	m_messageId.clear();
}

QByteArray DifyClient::buildMessageBody(const ChatSendMessage& msg)
{
	QJsonObject SendMessageBody;

	// Dify API�Ļ�������
	QJsonObject inputs; // Dify�����������ͨ�����ڴ��ݱ���

						// ����query���ݣ�������Ϣ+�ĵ�����
	QString finalQuery = msg.SendText;
	if (!msg.fileContext.isEmpty())
	{
		for (int i = 0; i < msg.fileContext.size(); i++)
		{
			finalQuery += QStringLiteral("\n �ĵ�%1����:").arg(i) + msg.fileContext[i];
		}
	}

	// ����˼��ģʽ����
	finalQuery += m_LLMParams->getOpenThink() ? "\\think" : "\\no_think";

	SendMessageBody["query"] = finalQuery;
	SendMessageBody["inputs"] = inputs; // �յ�inputs���󣬿ɸ�����Ҫ���ӱ���

										// ��Ӧģʽ����ʽ������ʽ
	SendMessageBody["response_mode"] = m_LLMParams->getStreamChat() ? "streaming" : "blocking";

	// �ỰID������еĻ���
	if (!m_conversationId.isEmpty())
	{
		SendMessageBody["conversation_id"] = m_conversationId;
	}

	// �û���ʶ����ѡ��
	if (!m_userId.isEmpty())
	{
		SendMessageBody["user"] = m_userId;
	}

	// ����ͼ�� - Difyͨ��ͨ��files���������ļ�
	if (!msg.Image64.isEmpty())
	{
		QJsonArray filesArray;
		for (const QString &base64Str : msg.Image64)
		{
			QJsonObject fileObj;
			fileObj["type"] = "image";
			fileObj["transfer_method"] = "local_file"; // �� "remote_url"

													   //���ǽ����ϴ��ļ���������ȡ�ļ�ID
			fileObj["upload_file_id"] = base64Str; // ʵ��ʹ������Ҫ���ϴ��ļ���ȡfile_id
			filesArray.append(fileObj);
		}
		SendMessageBody["files"] = filesArray;
	}

	// Dify���еĲ���
	SendMessageBody["auto_generate_name"] = true; // �Զ����ɶԻ�����

												  // ģ����ز��������DifyӦ��֧��ģ���л���
												  // ע�⣺Difyͨ����Ӧ�ò�����ģ�ͣ�API�㲻ֱ��ָ��ģ��
												  // ������ͨ��inputs����ģ����صĲ���
	if (m_LLMParams->getMaxToken() > 0)
	{
		inputs["max_tokens"] = m_LLMParams->getMaxToken();
	}
	if (m_LLMParams->getTemperature() >= 0)
	{
		inputs["temperature"] = m_LLMParams->getTemperature();
	}

	SendMessageBody["inputs"] = inputs;

	return QJsonDocument(SendMessageBody).toJson();
}

QByteArray DifyClient::buildStopAnswerBody()
{
	QJsonObject SendMessageBody;
	SendMessageBody["user"] = m_userId;
	return QJsonDocument(SendMessageBody).toJson();
}

void DifyClient::SendPreProcess(const ChatSendMessage& msg)
{
	QByteArray postData = buildMessageBody(msg);
	QSslConfiguration config = QSslConfiguration::defaultConfiguration();
	config.setProtocol(QSsl::AnyProtocol);
	config.setPeerVerifyMode(QSslSocket::VerifyNone);
	m_NetWorkParams->clientRequest.setSslConfiguration(config);
	m_NetWorkParams->clientNetWorkReply = std::unique_ptr<QNetworkReply>(m_NetWorkParams->clientNetWorkManager->post(m_NetWorkParams->clientRequest, postData));
}

QJsonObject DifyClient::parseJsonReplyToMsg(const QByteArray &data)
{
	QJsonDocument response_doc = QJsonDocument::fromJson(data);
	if (response_doc.isNull())
		return QJsonObject();

	QJsonObject rsp_json = response_doc.object();
	return rsp_json;
}

int DifyClient::send(const ChatSendMessage& msg)
{
	SendPreProcess(msg);
	connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished, this, &DifyClient::getAnswer);
	return true;
}

int DifyClient::StreamSend(const ChatSendMessage& msg)
{
	SendPreProcess(msg);
	connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::readyRead, this, &DifyClient::getStreamAnswer, Qt::QueuedConnection);
	connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished, this, &DifyClient::processStreamEnded);
	return true;
}

QString DifyClient::GetError(const QString& errorLevel, const QString& errorContext)
{
	ChangeButtonStatus(true);

	static const QMap<QString, QString> contextErrorMap = {
		{ "Connection timed out", QStringLiteral("��������ʱ") },
		{ "Permission denied", QStringLiteral("Ȩ�޲���") },
		{ "Connection refused", QStringLiteral("�������ܾ�����") }
	};

	if (contextErrorMap.contains(errorLevel))
	{
		return contextErrorMap.value(errorLevel);
	}
	else if (errorLevel.contains("not found"))
	{
		return tr("IP Address Error");
	}

	// ����HTTP����
	QString errorCode = MessageManager::extractHttpErrorCode(errorLevel);

	if (errorCode == "Bad Request")
	{
		const QString errorMsg = MessageManager::extractJsonField(errorContext, QStringLiteral("message"));
		if (!errorMsg.isEmpty())
		{
			return tr("Request Error: ") + errorMsg;
		}
		return tr("Please Check Input Setting");
	}
	else if (errorCode == "Unauthorized")
	{
		return tr("API Key Error");
	}
	else if (errorCode == "Forbidden")
	{
		return tr("Forbidden");
	}
	else if (errorCode == "Too Many Requests")
	{
		return tr("Too Many Requests,Please retry after mintues");
	}

	return tr("Unkonw Error") + errorLevel;
}

void DifyClient::processStreamEnded()
{
	if (m_NetWorkParams->clientNetWorkReply->error())
	{
		QString errorMsg = GetError(m_NetWorkParams->clientNetWorkReply->errorString(),
			m_NetWorkParams->clientNetWorkReply->readAll());
		emit Answer(errorMsg, true);
		return;
	}
	m_NetWorkParams->rawBuffer.clear();
	emit StreamEnded();
}

QNetworkRequest DifyClient::createApiRequest(const QUrl& url)
{
	QNetworkRequest request(url);

	// ����ͨ������ͷ
	request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
	request.setHeader(QNetworkRequest::UserAgentHeader, "DifyClient/1.0");

	// ����SSL
	QSslConfiguration config = QSslConfiguration::defaultConfiguration();
	config.setProtocol(QSsl::AnyProtocol);
	config.setPeerVerifyMode(QSslSocket::VerifyNone);
	request.setSslConfiguration(config);

	// ����Bearer token��֤
	QVariant authHeader = m_NetWorkParams->clientRequest.rawHeader("Authorization");
	if (authHeader.isValid())
	{
		request.setRawHeader("Authorization", authHeader.toByteArray());
	}

	return request;
}

void DifyClient::sendApiRequest(const QNetworkRequest& request, QTimer* timeoutTimer, int timeoutMs)
{
	if (m_currentRequestType == RequestType::StopStreamAns)
	{
		QByteArray postData = buildStopAnswerBody();
		m_NetWorkParams->clientNetWorkReply = std::unique_ptr<QNetworkReply>(
			m_NetWorkParams->clientNetWorkManager->post(request, postData));
		connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onStopStreamAnsFinished);
		return;
	}
	m_NetWorkParams->clientNetWorkReply = std::unique_ptr<QNetworkReply>(
		m_NetWorkParams->clientNetWorkManager->get(request));

	// ������������������Ӧ�Ĵ�������
	if (m_currentRequestType == RequestType::FetchModels)
	{
		connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onFetchModelsFinished);
		// ������ʱ��ʱ��
		timeoutTimer->start(timeoutMs);
	}
	else if (m_currentRequestType == RequestType::ConnectionCheck)
	{
		connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onCheckConnectionFinished);
		// ������ʱ��ʱ��
		timeoutTimer->start(timeoutMs);
	}
	else if (m_currentRequestType == RequestType::FollowUpSuggest)
	{
		connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onGetFollowUpSuggestFinished);
	}
	else if (m_currentRequestType == RequestType::GetKonwledgeBase)
	{
		connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onGetKnowledgeBaseFinished);
	}
}

QStringList DifyClient::parseModelIds(const QByteArray &jsonData)
{
	QStringList modelIds;

	// Difyͨ��������ģ���б�������ʹ��Ԥ���õ�Ӧ��
	// ���ﷵ��һ��Ĭ���б����߽���Ӧ���б�
	QJsonParseError parseError;
	QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData, &parseError);

	if (parseError.error != QJsonParseError::NoError) {
		// ����Ĭ�ϵ�DifyӦ������
		modelIds << "Chat Application" << "Text Generator" << "Agent";
		return modelIds;
	}

	QJsonObject jsonObj = jsonDoc.object();

	// �����Ӧ���б���Ӧ
	if (jsonObj.contains("data"))
	{
		QJsonArray appsArray = jsonObj["data"].toArray();
		for (const QJsonValue &appValue : appsArray)
		{
			if (appValue.isObject())
			{
				QJsonObject appObj = appValue.toObject();
				if (appObj.contains("name"))
				{
					QString appName = appObj["name"].toString();
					if (!appName.isEmpty())
					{
						modelIds.append(appName);
					}
				}
			}
		}
	}

	// ���û���ҵ�Ӧ�ã�����Ĭ���б�
	if (modelIds.isEmpty())
	{
		modelIds << "Default Chat App" << "Custom Application";
	}
	return modelIds;
}

QUrl DifyClient::buildApiUrl(const QString& endpoint)
{
	QUrl originalUrl = m_NetWorkParams->clientRequest.url();
	QUrl apiUrl;
	apiUrl.setScheme(originalUrl.scheme());
	apiUrl.setHost(originalUrl.host());
	apiUrl.setPath(endpoint);
	qDebug() << apiUrl.toString();
	return apiUrl;
}

QUrl DifyClient::buildApiUrl(const QString& apiPath, const QString& User)
{
	QUrl originalUrl = m_NetWorkParams->clientRequest.url();
	QUrl apiUrl;
	apiUrl.setScheme(originalUrl.scheme());
	apiUrl.setHost(originalUrl.host());
	apiUrl.setPath(apiPath);
	apiUrl.setQuery("user=" + User);
	qDebug() << apiUrl.toString();
	return apiUrl;
}

void DifyClient::getAnswer()
{
	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		QByteArray read_data = m_NetWorkParams->clientNetWorkReply->readAll();
		QJsonDocument response_doc = QJsonDocument::fromJson(read_data);
		QJsonObject response_obj = response_doc.object();

		AnalysisBlockResponse(response_obj);
	}
	else
	{
		emit Answer(GetError(m_NetWorkParams->clientNetWorkReply->errorString(),
			m_NetWorkParams->clientNetWorkReply->readAll()), true);
	}
	m_NetWorkParams->clientNetWorkReply.reset();
	ChangeButtonStatus(true);
}

void DifyClient::AnalysisBlockResponse(QJsonObject& response_obj)
{
	QString textresponse;

	// ����Dify����Ӧ��ʽ
	if (response_obj.contains("answer"))
	{
		textresponse = response_obj["answer"].toString();

		// ����conversation_id���ں����Ի�
		if (response_obj.contains("conversation_id"))
		{
			m_conversationId = response_obj["conversation_id"].toString();
		}
		if (response_obj.contains("message_id"))
		{
			m_messageId = response_obj["message_id"].toString();
		}
		if (response_obj.contains("task_id"))
		{
			m_taskId = response_obj["task_id"].toString();
		}

		emit Answer(textresponse, false);
	}
	else if (response_obj.contains("message"))
	{
		textresponse = response_obj["message"].toString();
		emit Answer(textresponse, true);
	}
	else
	{
		emit Answer("Invalid response format", true);
	}
}

void DifyClient::getStreamAnswer()
{
	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		QByteArray response_data = m_NetWorkParams->clientNetWorkReply->readAll();
		m_NetWorkParams->rawBuffer.append(response_data);

		// Dify��ʽ��Ӧ��ʽ: data: {...}\n\n
		QString dataStr = QString::fromUtf8(response_data);
		QStringList lines = dataStr.split('\n');

		for (const QString& line : lines)
		{
			if (line.startsWith("data: "))
			{
				QString jsonStr = line.mid(6); // �Ƴ�"data: "ǰ׺
				if (jsonStr.trimmed() == "[DONE]")
				{
					continue; // �����������
				}

				QJsonDocument doc = QJsonDocument::fromJson(jsonStr.toUtf8());
				if (!doc.isNull())
				{
					QJsonObject obj = doc.object();
					AnalysisStreamResponse(obj);
				}
			}
		}
	}
}

void DifyClient::AnalysisStreamResponse(QJsonObject& eventObj)
{
	// ������ͬ���¼�����
	QString event = eventObj["event"].toString();

	if (event == "message")
	{
		QString answer = eventObj["answer"].toString();
		if (!answer.isEmpty())
		{
			emit AnswerStream(answer);
		}

		// ����conversation_id
		if (eventObj.contains("conversation_id"))
		{
			m_conversationId = eventObj["conversation_id"].toString();
		}
		if (eventObj.contains("message_id"))
		{
			m_messageId = eventObj["message_id"].toString();
		}
		if (eventObj.contains("task_id"))
		{
			m_taskId = eventObj["task_id"].toString();
		}
	}
	else if (event == "message_end")
	{
		// ��Ϣ���������Ի�ȡusage��Ϣ
		if (eventObj.contains("metadata"))
		{
			QJsonObject metadata = eventObj["metadata"].toObject();
			if (metadata.contains("usage"))
			{
				QJsonObject usage = metadata["usage"].toObject();
				int totalTokens = usage["total_tokens"].toInt();
			}
		}
	}
	else if (event == "error")
	{
		QString errorMsg = eventObj["message"].toString();
		emit Answer("Stream error: " + errorMsg, true);
		return;
	}
}

void DifyClient::checkServerConnectionAsync(int timeoutMs)
{
	// ȡ��֮ǰ������
	cancelCurrentRequest();

	// ������������
	m_currentRequestType = RequestType::ConnectionCheck;

	// ��֤URL
	if (!validateServerUrl())
	{
		emit serverConnectionCheckFinished(false, tr("URL Error"));
		return;
	}

	// Dify���Ӳ���ʹ�û���API�˵�
	QUrl testUrl = buildApiUrl("/v1/info");
	QNetworkRequest testRequest = createApiRequest(testUrl);
	sendApiRequest(testRequest, m_connectionCheckTimer, timeoutMs);
}

void DifyClient::onCheckConnectionFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply) {
		return;
	}

	// ����Ƿ�ʱ
	if (!m_connectionCheckTimer->isActive()) {
		m_NetWorkParams->clientNetWorkReply.reset();
		return;
	}

	m_connectionCheckTimer->stop();

	bool isConnected = false;
	QString errorMessage;

	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200)
		{
			isConnected = true;
			errorMessage = "Dify connection successful";
		}
		else
		{
			errorMessage = QString("HTTP Error: %1").arg(statusCode);
		}
	}
	else
	{
		errorMessage = m_NetWorkParams->clientNetWorkReply->errorString();
	}

	m_NetWorkParams->clientNetWorkReply.reset();
	emit serverConnectionCheckFinished(isConnected, errorMessage);
}

void DifyClient::fetchModelsAsync(int timeoutMs)
{
	// Dify���ṩģ���б�API��ֱ�ӷ��سɹ�
	QStringList defaultApps;
	defaultApps << "Chat Application" << "Text Generator" << "Workflow" << "Agent";
	m_availableModelIds = defaultApps;

	emit modelsListFetched(true, m_availableModelIds, "Using default Dify application types");
}

void DifyClient::onFetchModelsFinished()
{
	// Difyͨ������Ҫʵ�ʻ�ȡģ���б���ֱ��ʹ��Ĭ��Ӧ������
	QStringList models;
	models << "Chat Application" << "Text Generator" << "Workflow" << "Agent";
	m_availableModelIds = models;

	emit modelsListFetched(true, m_availableModelIds, "Dify application types loaded");
}

void DifyClient::onCheckConnectionTimeout()
{
	if (m_NetWorkParams->clientNetWorkReply)
	{
		disconnect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
			this, &DifyClient::onCheckConnectionFinished);

		m_NetWorkParams->clientNetWorkReply->abort();
		m_NetWorkParams->clientNetWorkReply.reset();
	}
	emit serverConnectionCheckFinished(false, tr("Please Check IP Address or Network Setting"));
}

void DifyClient::onFetchModelsTimeout()
{
	// Dify����Ҫʵ�ʳ�ʱ������ֱ�ӷ���Ĭ���б�
	QStringList models;
	models << "Chat Application" << "Text Generator" << "Workflow" << "Agent";
	emit modelsListFetched(true, models, "Using default Dify application types");
}

QStringList DifyClient::GetFollowUpSuggestions()
{
	// ȡ��֮ǰ������
	cancelCurrentRequest();

	// ������������
	m_currentRequestType = RequestType::FollowUpSuggest;

	if (!validateServerUrl())
	{
		return QStringList();
	}
	QString endpoint = "/v1/messages/" + m_messageId + "/" + "suggested";
	QUrl suggestUrl = buildApiUrl(endpoint, m_userId);
	QNetworkRequest suggestRequest = createApiRequest(suggestUrl);
	sendApiRequest(suggestRequest, m_fetchModelsTimer, 5000);
}

void DifyClient::onGetFollowUpSuggestFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply) {
		return;
	}

	bool success = false;
	QString errorMessage;
	QStringList suggestions;

	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200)
		{
			QByteArray responseData = m_NetWorkParams->clientNetWorkReply->readAll();
			QJsonParseError error;
			QJsonDocument doc = QJsonDocument::fromJson(responseData, &error);

			// �������Ƿ�ɹ�
			if (error.error != QJsonParseError::NoError)
				return;
			// ����Ƿ�Ϊ����
			if (!doc.isObject())
				return;
			QJsonObject obj = doc.object();

			// ����Ƿ����data�ֶ�
			if (!obj.contains("data"))
				return;

			// ��ȡdata�ֶε�ֵ
			QJsonValue dataValue = obj.value("data");

			// ���data�Ƿ�Ϊ����
			if (!dataValue.isArray())
				return;

			QJsonArray dataArray = dataValue.toArray();

			// �������飬���ַ������ӵ�QStringList
			for (const QJsonValue& value : dataArray)
			{
				if (value.isString())
				{
					suggestions.append(value.toString());
				}
			}
			if (!suggestions.isEmpty())
			{
				success = true;
				errorMessage = QString("Successfully fetched %1 suggestions").arg(suggestions.size());
				FollowSuggestSignal(suggestions);
			}
			else
			{
				errorMessage = "No models found in response";
			}
		}
		else
		{
			errorMessage = QString("HTTP Error: %1").arg(statusCode);
		}
	}
	else
	{
		errorMessage = m_NetWorkParams->clientNetWorkReply->errorString();
	}

	m_NetWorkParams->clientNetWorkReply.reset();
}

void DifyClient::getKnowledgeBase()
{
	// ȡ��֮ǰ������
	cancelCurrentRequest();

	// ������������
	m_currentRequestType = RequestType::GetKonwledgeBase;

	if (!validateServerUrl())
		return;

	QUrl KnowledgeUrl = buildApiUrl("/v1/datasets");
	QNetworkRequest request(KnowledgeUrl);

	// ����ͨ������ͷ
	request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
	request.setHeader(QNetworkRequest::UserAgentHeader, "DifyClient/1.0");

	// ����SSL
	QSslConfiguration config = QSslConfiguration::defaultConfiguration();
	config.setProtocol(QSsl::AnyProtocol);
	config.setPeerVerifyMode(QSslSocket::VerifyNone);
	request.setSslConfiguration(config);

	// ����Bearer token��֤
	QVariant authHeader = m_LLMParams->getKnowledgeApi();
	if (authHeader.isValid())
	{
		request.setRawHeader("Authorization", ("Bearer " + m_LLMParams->getKnowledgeApi()).toUtf8());
	}
	sendApiRequest(request, m_fetchModelsTimer, 50000);
}

void DifyClient::onGetKnowledgeBaseFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply)
		return;

	bool success = false;
	QString errorMessage;

	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200)
		{
			QByteArray responseData = m_NetWorkParams->clientNetWorkReply->readAll();
			QJsonParseError error;
			QJsonDocument doc = QJsonDocument::fromJson(responseData, &error);
			QJsonObject jsonObj = doc.object();
			QJsonArray jsonArray = jsonObj.value("data").toArray();

			for (const QJsonValue& value : jsonArray)
			{
				if (!value.isObject())
					continue;
				QJsonObject obj = value.toObject();

				// �������ֶ��Ƿ����
				if (!obj.contains("id") || !obj.contains("name") || !obj.contains("description"))
					continue;

				KnowledgeBase kb;
				kb.KnowledgeID = obj["id"].toString();
				kb.KnowledgeName = obj["name"].toString();
				kb.KnowledgeDescription = obj["description"].toString();

				// ��֤�ֶβ�Ϊ��
				if (kb.KnowledgeID.isEmpty() || kb.KnowledgeName.isEmpty())
					continue;
				KnowledgeInfo.push_back(kb);
			}
		}
		else
		{
			errorMessage = QString("HTTP Error: %1").arg(statusCode);
		}
	}
	else
	{
		errorMessage = m_NetWorkParams->clientNetWorkReply->errorString();
	}
	m_NetWorkParams->clientNetWorkReply.reset();
}

void DifyClient::StopGenerateStreamAns()
{
	// ȡ��֮ǰ������
	cancelCurrentRequest();

	// ������������
	m_currentRequestType = RequestType::StopStreamAns;

	if (!validateServerUrl())
		return;

	QString endpoint = "/v1/messages/" + m_taskId + "/" + "stop";
	QUrl suggestUrl = buildApiUrl(endpoint, m_userId);
	QNetworkRequest suggestRequest = createApiRequest(suggestUrl);
	sendApiRequest(suggestRequest, m_fetchModelsTimer, 50000);
}

void DifyClient::onStopStreamAnsFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply)
		return;
	bool success = false;
	QString errorMessage;

	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200)
			errorMessage = "success";
	}
}

void DifyClient::uploadFile(const QString& filePath)
{
	// ȡ��֮ǰ������
	cancelCurrentRequest();

	// ������������
	m_currentRequestType = RequestType::FileUpload;

	// ��֤URL
	if (!validateServerUrl())
		return;
	QFileInfo fileInfo(filePath);
	QFile* file = new QFile(filePath);
	if (!file->open(QIODevice::ReadOnly))
	{
		delete file;
		return;
	}

	// �����ļ��ϴ�URL
	QUrl uploadUrl = buildApiUrl("/v1/files/upload");
	QNetworkRequest uploadRequest(uploadUrl);

	// ����SSL
	QSslConfiguration config = QSslConfiguration::defaultConfiguration();
	config.setProtocol(QSsl::AnyProtocol);
	config.setPeerVerifyMode(QSslSocket::VerifyNone);
	uploadRequest.setSslConfiguration(config);

	// ����Bearer token��֤
	QVariant authHeader = m_NetWorkParams->clientRequest.rawHeader("Authorization");
	if (authHeader.isValid())
	{
		uploadRequest.setRawHeader("Authorization", authHeader.toByteArray());
	}
	// ����multipart/form-data
	QHttpMultiPart* multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);

	// �����ļ�����
	QMimeDatabase mimeDb;

	// �ȳ��Ը����������ݼ��
	QMimeType mimeType = mimeDb.mimeTypeForFile(filePath);
	QString filenametype = mimeType.name();
	QHttpPart filePart;
	filePart.setHeader(QNetworkRequest::ContentTypeHeader, filenametype.toUtf8());
	filePart.setHeader(QNetworkRequest::ContentDispositionHeader,
		QString("form-data; name=\"file\"; filename=\"%1\"")
		.arg(QFileInfo(filePath).fileName()));

	filePart.setBodyDevice(file);
	file->setParent(multiPart); // ȷ���ļ����������������multiPart����

	multiPart->append(filePart);

	// ����user����������еĻ���
	if (!m_userId.isEmpty())
	{
		QHttpPart userPart;
		userPart.setHeader(QNetworkRequest::ContentDispositionHeader, "form-data; name=\"user\"");
		userPart.setBody(m_userId.toUtf8());
		multiPart->append(userPart);
	}

	// ����POST����
	m_NetWorkParams->clientNetWorkReply = std::unique_ptr<QNetworkReply>(
		m_NetWorkParams->clientNetWorkManager->post(uploadRequest, multiPart));

	// multiPart����replyɾ��ʱ�Զ�ɾ��
	multiPart->setParent(m_NetWorkParams->clientNetWorkReply.get());

	// �����ź�
	connect(m_NetWorkParams->clientNetWorkReply.get(), &QNetworkReply::finished,
		this, &DifyClient::onFileUploadFinished);
}

void DifyClient::DeleteFile(const QString& fileID)
{

}

void DifyClient::onFileUploadFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply)
		return;
	bool success = false;
	QString errorMessage;
	QString fileId;
	QString fileName;

	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200 || statusCode == 201)
		{
			QByteArray responseData = m_NetWorkParams->clientNetWorkReply->readAll();
			QJsonParseError error;
			QJsonDocument doc = QJsonDocument::fromJson(responseData, &error);

			if (error.error == QJsonParseError::NoError && doc.isObject())
			{
				QJsonObject obj = doc.object();

				// ����Dify�ļ��ϴ���Ӧ
				if (obj.contains("id"))
				{
					fileId = obj["id"].toString();
					fileName = obj["name"].toString();
					m_UpFiles.insert(fileName, fileId);
					success = true;
					errorMessage = "�ļ��ϴ��ɹ�";
				}
				else
				{
					errorMessage = "��Ӧ��δ�ҵ��ļ�ID";
				}
			}
			else
			{
				errorMessage = "��Ӧ����ʧ��: " + error.errorString();
			}
		}
		else
		{
			QByteArray responseData = m_NetWorkParams->clientNetWorkReply->readAll();
			QJsonDocument doc = QJsonDocument::fromJson(responseData);
			if (doc.isObject())
			{
				QJsonObject obj = doc.object();
				if (obj.contains("message"))
				{
					errorMessage = QString("HTTP %1: %2").arg(statusCode).arg(obj["message"].toString());
				}
				else
				{
					errorMessage = QString("HTTP����: %1").arg(statusCode);
				}
			}
			else
			{
				errorMessage = QString("HTTP����: %1").arg(statusCode);
			}
		}
	}
	else
	{
		errorMessage = GetError(m_NetWorkParams->clientNetWorkReply->errorString(),
			m_NetWorkParams->clientNetWorkReply->readAll());
	}

	m_NetWorkParams->clientNetWorkReply.reset();
}

void DifyClient::onDeleteFileFinished()
{
	if (!m_NetWorkParams->clientNetWorkReply)
		return;
	bool success = false;
	QString errorMessage;
	if (m_NetWorkParams->clientNetWorkReply->error() == QNetworkReply::NoError)
	{
		int statusCode = m_NetWorkParams->clientNetWorkReply->attribute(
			QNetworkRequest::HttpStatusCodeAttribute).toInt();

		if (statusCode == 200 || statusCode == 201)
		{
			QByteArray responseData = m_NetWorkParams->clientNetWorkReply->readAll();
			QJsonParseError error;
			QJsonDocument doc = QJsonDocument::fromJson(responseData, &error);

			if (error.error == QJsonParseError::NoError && doc.isObject())
			{
				QJsonObject obj = doc.object();
				errorMessage = obj["message"].toString();
				qDebug() << errorMessage;
			}
			else
			{
				errorMessage = "��Ӧ����ʧ��: " + error.errorString();
			}
		}
	}
	else
	{
		errorMessage = GetError(m_NetWorkParams->clientNetWorkReply->errorString(),
			m_NetWorkParams->clientNetWorkReply->readAll());
	}

	m_NetWorkParams->clientNetWorkReply.reset();
}

void DifyClient::ChangeKnowledgeGraph(const QString& kownledgeID)
{

}

void DifyClient::CancelUpdateFile(const QString& file)
{
	QFileInfo fileInfo(file);
	QString fileName = fileInfo.fileName();
	auto it = m_UpFiles.find(fileName);
	if (it != m_UpFiles.end())
		m_UpFiles.erase(it);
}

void DifyClient::CancelAllUpdateFiles(const QStringList& fileList)
{
	for (auto file : fileList)
	{
		CancelUpdateFile(file);
	}
}